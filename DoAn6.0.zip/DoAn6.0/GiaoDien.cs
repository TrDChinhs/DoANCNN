﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAn6._0 
{
    public partial class GiaoDien : Form
    {
        private string currentLoggedInUsername;

        public GiaoDien(string username)
        {
            InitializeComponent();
            this.currentLoggedInUsername = username;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DuBaoThoiTiet duBaoThoiTiet = new DuBaoThoiTiet();
            duBaoThoiTiet.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.currentLoggedInUsername))
            {
                // Sử dụng tên tài khoản đã lưu trữ
                CapNhatTaiKhoan capNhatTaiKhoan = new CapNhatTaiKhoan(this.currentLoggedInUsername);
                capNhatTaiKhoan.Show(); 
                this.Hide();
            }
            else
            {
                MessageBox.Show("Lỗi: Không xác định được thông tin người dùng để cập nhật.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DangNhap loginForm = new DangNhap();
                loginForm.Show();
                this.Close();
            }
        }

        private void GiaoDien_Load(object sender, EventArgs e)
        {
        }
    }
}