﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using DoAn6._0;

namespace DoAn6._0
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
            txtMatKhau.PasswordChar = '*';
            txtMatKhau.Text = "";
            txtTaiKhoan.Text = "";
            this.txtMatKhau.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMatKhau_KeyDown);

            this.DoubleBuffered = true;

            this.panel1.Paint += Panel1_Paint;
            this.panelRounded.Paint += PanelRounded_Paint;

            this.panel1.Resize += (s, e) => this.panel1.Invalidate();
            this.panelRounded.Resize += (s, e) => this.panelRounded.Invalidate();
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {
            Panel panel = sender as Panel;
            if (panel == null) return;

            int radius = 10; // Điều chỉnh bán kính bo góc ở đây
            Rectangle bounds = new Rectangle(0, 0, panel.Width, panel.Height);

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            using (GraphicsPath path = CreateRoundedRectPath(bounds, radius, true, true, false, false)) // topLeft, topRight = true
            {
                panel.Region = new Region(path);
            }
        }

        private void PanelRounded_Paint(object sender, PaintEventArgs e)
        {
            Panel panel = sender as Panel;
            if (panel == null) return;

            int radius = 10; // Điều chỉnh bán kính bo góc ở đây
            Rectangle bounds = new Rectangle(0, 0, panel.Width, panel.Height);

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            using (GraphicsPath path = CreateRoundedRectPath(bounds, radius, false, false, true, true)) // bottomLeft, bottomRight = true
            {
                panel.Region = new Region(path);
            }
        }

        private GraphicsPath CreateRoundedRectPath(Rectangle bounds, int radius, bool topLeft = true, bool topRight = true, bool bottomLeft = true, bool bottomRight = true)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;

            if (diameter <= 0) 
            {
                path.AddRectangle(bounds);
                path.CloseFigure();
                return path;
            }

            if (diameter > bounds.Width) diameter = bounds.Width;
            if (diameter > bounds.Height) diameter = bounds.Height;

            Rectangle arcRect = new Rectangle(bounds.Location, new Size(diameter, diameter));

            // Top-Left Arc
            if (topLeft) path.AddArc(arcRect, 180, 90);
            else path.AddLine(bounds.Left, bounds.Top + radius, bounds.Left, bounds.Top);

            // Top Edge
            path.AddLine(bounds.Left + (topLeft ? radius : 0), bounds.Top, bounds.Right - (topRight ? radius : 0), bounds.Top);

            // Top-Right Arc
            arcRect.X = bounds.Right - diameter;
            if (topRight) path.AddArc(arcRect, 270, 90);
            else path.AddLine(bounds.Right, bounds.Top, bounds.Right, bounds.Top + radius);

            // Right Edge
            path.AddLine(bounds.Right, bounds.Top + (topRight ? radius : 0), bounds.Right, bounds.Bottom - (bottomRight ? radius : 0));

            // Bottom-Right Arc
            arcRect.Y = bounds.Bottom - diameter;
            if (bottomRight) path.AddArc(arcRect, 0, 90);
            else path.AddLine(bounds.Right, bounds.Bottom - radius, bounds.Right, bounds.Bottom);

            // Bottom Edge
            path.AddLine(bounds.Right - (bottomRight ? radius : 0), bounds.Bottom, bounds.Left + (bottomLeft ? radius : 0), bounds.Bottom);

            // Bottom-Left Arc
            arcRect.X = bounds.Left;
            if (bottomLeft) path.AddArc(arcRect, 90, 90);
            else path.AddLine(bounds.Left, bounds.Bottom, bounds.Left, bounds.Bottom - radius);

            // Left Edge
            path.AddLine(bounds.Left, bounds.Bottom - (bottomLeft ? radius : 0), bounds.Left, bounds.Top + (topLeft ? radius : 0));

            path.CloseFigure();
            return path;
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
                string tenDangNhap = txtTaiKhoan.Text.Trim();
            string matKhau = txtMatKhau.Text.Trim(); 

            if (string.IsNullOrEmpty(tenDangNhap))
            {
                MessageBox.Show("Vui lòng nhập Tên đăng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTaiKhoan.Focus();
                return;
            }

            if (string.IsNullOrEmpty(matKhau))
            {
                MessageBox.Show("Vui lòng nhập Mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMatKhau.Focus();
                return;
            }

            Modify modify = new Modify();

            bool isValidLogin = modify.CheckLogin(tenDangNhap, matKhau);

            if (isValidLogin)
            {
                MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GiaoDien giaoDien = new GiaoDien(tenDangNhap); // *** QUAN TRỌNG ***
                giaoDien.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Tên đăng nhập hoặc Mật khẩu không chính xác. Vui lòng thử lại!", "Lỗi đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMatKhau.Text = "";
                txtMatKhau.Focus();
            }
        }

        private void txtMatKhau_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                btnDangNhap_Click(sender, e);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            QuenMatKhau quenMatKhauForm = new QuenMatKhau();
            quenMatKhauForm.Show();
            this.Hide();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DangKy dangKyForm = new DangKy();
            dangKyForm.Show();
            this.Hide();
        }

        private void DangNhap_Load(object sender, EventArgs e)
        {

        }
    }
}