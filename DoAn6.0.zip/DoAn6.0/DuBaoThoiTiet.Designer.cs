﻿namespace DoAn6._0
{
    partial class DuBaoThoiTiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanelDays = new System.Windows.Forms.FlowLayoutPanel();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPageNhietDo = new MetroFramework.Controls.MetroTabPage();
            this.chartTemperature = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.duBaoThoiTietBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.quanLyNongTraiDataSet = new DoAn6._0.QuanLyNongTraiDataSet();
            this.metroTabPageLuongMua = new MetroFramework.Controls.MetroTabPage();
            this.chartPrecipitation = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroTabPageGio = new MetroFramework.Controls.MetroTabPage();
            this.chartWind = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.picMainWeatherIcon = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMaxTempValue = new System.Windows.Forms.Label();
            this.labelwind = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblHumidityValue = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblRainChanceValue = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblTodayName = new System.Windows.Forms.Label();
            this.duBaoThoiTietTableAdapter = new DoAn6._0.QuanLyNongTraiDataSetTableAdapters.DuBaoThoiTietTableAdapter();
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.panel1.SuspendLayout();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPageNhietDo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartTemperature)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.duBaoThoiTietBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quanLyNongTraiDataSet)).BeginInit();
            this.metroTabPageLuongMua.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPrecipitation)).BeginInit();
            this.metroTabPageGio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartWind)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMainWeatherIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(18)))), ((int)(((byte)(24)))));
            this.panel1.Controls.Add(this.flowLayoutPanelDays);
            this.panel1.Controls.Add(this.metroTabControl1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.picMainWeatherIcon);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblMaxTempValue);
            this.panel1.Controls.Add(this.labelwind);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lblHumidityValue);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblRainChanceValue);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblDescription);
            this.panel1.Controls.Add(this.lblTodayName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(5, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1191, 551);
            this.panel1.TabIndex = 0;
            // 
            // flowLayoutPanelDays
            // 
            this.flowLayoutPanelDays.AutoScroll = true;
            this.flowLayoutPanelDays.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(18)))), ((int)(((byte)(24)))));
            this.flowLayoutPanelDays.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanelDays.Location = new System.Drawing.Point(0, 401);
            this.flowLayoutPanelDays.Name = "flowLayoutPanelDays";
            this.flowLayoutPanelDays.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.flowLayoutPanelDays.Size = new System.Drawing.Size(1191, 150);
            this.flowLayoutPanelDays.TabIndex = 2;
            this.flowLayoutPanelDays.WrapContents = false;
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPageNhietDo);
            this.metroTabControl1.Controls.Add(this.metroTabPageLuongMua);
            this.metroTabControl1.Controls.Add(this.metroTabPageGio);
            this.metroTabControl1.Location = new System.Drawing.Point(-12, 154);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 1;
            this.metroTabControl1.Size = new System.Drawing.Size(1214, 261);
            this.metroTabControl1.TabIndex = 3;
            this.metroTabControl1.UseSelectable = true;
            // 
            // metroTabPageNhietDo
            // 
            this.metroTabPageNhietDo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(18)))), ((int)(((byte)(24)))));
            this.metroTabPageNhietDo.Controls.Add(this.chartTemperature);
            this.metroTabPageNhietDo.HorizontalScrollbarBarColor = true;
            this.metroTabPageNhietDo.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPageNhietDo.HorizontalScrollbarSize = 8;
            this.metroTabPageNhietDo.Location = new System.Drawing.Point(4, 38);
            this.metroTabPageNhietDo.Name = "metroTabPageNhietDo";
            this.metroTabPageNhietDo.Padding = new System.Windows.Forms.Padding(3);
            this.metroTabPageNhietDo.Size = new System.Drawing.Size(1206, 219);
            this.metroTabPageNhietDo.TabIndex = 0;
            this.metroTabPageNhietDo.Text = "     Nhiệt Độ     ";
            this.metroTabPageNhietDo.VerticalScrollbarBarColor = true;
            this.metroTabPageNhietDo.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPageNhietDo.VerticalScrollbarSize = 22;
            // 
            // chartTemperature
            // 
            this.chartTemperature.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(18)))), ((int)(((byte)(24)))));
            chartArea1.Name = "DefaultArea";
            this.chartTemperature.ChartAreas.Add(chartArea1);
            this.chartTemperature.DataSource = this.duBaoThoiTietBindingSource;
            this.chartTemperature.Dock = System.Windows.Forms.DockStyle.Top;
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chartTemperature.Legends.Add(legend1);
            this.chartTemperature.Location = new System.Drawing.Point(3, 3);
            this.chartTemperature.Name = "chartTemperature";
            this.chartTemperature.Size = new System.Drawing.Size(1200, 206);
            this.chartTemperature.TabIndex = 1;
            this.chartTemperature.Text = "Biểu đồ Nhiệt Độ";
            // 
            // duBaoThoiTietBindingSource
            // 
            this.duBaoThoiTietBindingSource.DataMember = "DuBaoThoiTiet";
            this.duBaoThoiTietBindingSource.DataSource = this.quanLyNongTraiDataSet;
            // 
            // quanLyNongTraiDataSet
            // 
            this.quanLyNongTraiDataSet.DataSetName = "QuanLyNongTraiDataSet";
            this.quanLyNongTraiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroTabPageLuongMua
            // 
            this.metroTabPageLuongMua.Controls.Add(this.chartPrecipitation);
            this.metroTabPageLuongMua.HorizontalScrollbarBarColor = true;
            this.metroTabPageLuongMua.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPageLuongMua.HorizontalScrollbarSize = 8;
            this.metroTabPageLuongMua.Location = new System.Drawing.Point(4, 38);
            this.metroTabPageLuongMua.Name = "metroTabPageLuongMua";
            this.metroTabPageLuongMua.Padding = new System.Windows.Forms.Padding(3);
            this.metroTabPageLuongMua.Size = new System.Drawing.Size(1206, 219);
            this.metroTabPageLuongMua.TabIndex = 1;
            this.metroTabPageLuongMua.Text = "    Lượng Mưa    ";
            this.metroTabPageLuongMua.VerticalScrollbarBarColor = true;
            this.metroTabPageLuongMua.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPageLuongMua.VerticalScrollbarSize = 22;
            // 
            // chartPrecipitation
            // 
            this.chartPrecipitation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(18)))), ((int)(((byte)(24)))));
            chartArea2.Name = "ChartArea1";
            this.chartPrecipitation.ChartAreas.Add(chartArea2);
            this.chartPrecipitation.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Name = "Legend1";
            this.chartPrecipitation.Legends.Add(legend2);
            this.chartPrecipitation.Location = new System.Drawing.Point(3, 3);
            this.chartPrecipitation.Name = "chartPrecipitation";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartPrecipitation.Series.Add(series1);
            this.chartPrecipitation.Size = new System.Drawing.Size(1200, 213);
            this.chartPrecipitation.TabIndex = 2;
            this.chartPrecipitation.Text = "chart1";
            // 
            // metroTabPageGio
            // 
            this.metroTabPageGio.Controls.Add(this.chartWind);
            this.metroTabPageGio.HorizontalScrollbarBarColor = true;
            this.metroTabPageGio.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPageGio.HorizontalScrollbarSize = 8;
            this.metroTabPageGio.Location = new System.Drawing.Point(4, 38);
            this.metroTabPageGio.Name = "metroTabPageGio";
            this.metroTabPageGio.Padding = new System.Windows.Forms.Padding(3);
            this.metroTabPageGio.Size = new System.Drawing.Size(1206, 219);
            this.metroTabPageGio.TabIndex = 2;
            this.metroTabPageGio.Text = "          Gió          ";
            this.metroTabPageGio.VerticalScrollbarBarColor = true;
            this.metroTabPageGio.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPageGio.VerticalScrollbarSize = 22;
            // 
            // chartWind
            // 
            this.chartWind.BackColor = System.Drawing.Color.Black;
            chartArea3.Name = "ChartArea1";
            this.chartWind.ChartAreas.Add(chartArea3);
            this.chartWind.Dock = System.Windows.Forms.DockStyle.Fill;
            legend3.Name = "Legend1";
            this.chartWind.Legends.Add(legend3);
            this.chartWind.Location = new System.Drawing.Point(3, 3);
            this.chartWind.Name = "chartWind";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartWind.Series.Add(series2);
            this.chartWind.Size = new System.Drawing.Size(1200, 213);
            this.chartWind.TabIndex = 2;
            this.chartWind.Text = "chart1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(164, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "°F";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(155, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "|";
            // 
            // picMainWeatherIcon
            // 
            this.picMainWeatherIcon.BackColor = System.Drawing.Color.Transparent;
            this.picMainWeatherIcon.Location = new System.Drawing.Point(21, 29);
            this.picMainWeatherIcon.Name = "picMainWeatherIcon";
            this.picMainWeatherIcon.Size = new System.Drawing.Size(64, 64);
            this.picMainWeatherIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picMainWeatherIcon.TabIndex = 4;
            this.picMainWeatherIcon.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(133, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "°C";
            // 
            // lblMaxTempValue
            // 
            this.lblMaxTempValue.AutoSize = true;
            this.lblMaxTempValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F);
            this.lblMaxTempValue.Location = new System.Drawing.Point(81, 39);
            this.lblMaxTempValue.Name = "lblMaxTempValue";
            this.lblMaxTempValue.Size = new System.Drawing.Size(75, 54);
            this.lblMaxTempValue.TabIndex = 2;
            this.lblMaxTempValue.Text = "10";
            // 
            // labelwind
            // 
            this.labelwind.AutoSize = true;
            this.labelwind.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelwind.Location = new System.Drawing.Point(238, 104);
            this.labelwind.Name = "labelwind";
            this.labelwind.Size = new System.Drawing.Size(71, 25);
            this.labelwind.TabIndex = 2;
            this.labelwind.Text = "0 km/h";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(202, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Gió:";
            // 
            // lblHumidityValue
            // 
            this.lblHumidityValue.AutoSize = true;
            this.lblHumidityValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblHumidityValue.Location = new System.Drawing.Point(262, 70);
            this.lblHumidityValue.Name = "lblHumidityValue";
            this.lblHumidityValue.Size = new System.Drawing.Size(41, 25);
            this.lblHumidityValue.TabIndex = 2;
            this.lblHumidityValue.Text = "0%";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(202, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 25);
            this.label6.TabIndex = 2;
            this.label6.Text = "Độ ẩm:";
            // 
            // lblRainChanceValue
            // 
            this.lblRainChanceValue.AutoSize = true;
            this.lblRainChanceValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblRainChanceValue.Location = new System.Drawing.Point(338, 40);
            this.lblRainChanceValue.Name = "lblRainChanceValue";
            this.lblRainChanceValue.Size = new System.Drawing.Size(41, 25);
            this.lblRainChanceValue.TabIndex = 2;
            this.lblRainChanceValue.Text = "0%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(202, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 25);
            this.label5.TabIndex = 2;
            this.label5.Text = "Khả năng có mưa: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(1033, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 38);
            this.label1.TabIndex = 2;
            this.label1.Text = "Thời tiết";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblDescription.Location = new System.Drawing.Point(1036, 91);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(64, 28);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Mô tả";
            // 
            // lblTodayName
            // 
            this.lblTodayName.AutoSize = true;
            this.lblTodayName.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTodayName.Location = new System.Drawing.Point(1035, 48);
            this.lblTodayName.Name = "lblTodayName";
            this.lblTodayName.Size = new System.Drawing.Size(45, 28);
            this.lblTodayName.TabIndex = 2;
            this.lblTodayName.Text = "Thứ";
            // 
            // duBaoThoiTietTableAdapter
            // 
            this.duBaoThoiTietTableAdapter.ClearBeforeFill = true;
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = null;
            // 
            // DuBaoThoiTiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 617);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "DuBaoThoiTiet";
            this.Padding = new System.Windows.Forms.Padding(5, 60, 5, 6);
            this.Text = "Dự Báo Thời Tiết";
            this.Load += new System.EventHandler(this.DuBaoThoiTiet_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPageNhietDo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartTemperature)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.duBaoThoiTietBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quanLyNongTraiDataSet)).EndInit();
            this.metroTabPageLuongMua.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartPrecipitation)).EndInit();
            this.metroTabPageGio.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartWind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMainWeatherIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTemperature;
        private QuanLyNongTraiDataSet quanLyNongTraiDataSet;
        private System.Windows.Forms.BindingSource duBaoThoiTietBindingSource;
        private QuanLyNongTraiDataSetTableAdapters.DuBaoThoiTietTableAdapter duBaoThoiTietTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTodayName;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblMaxTempValue;
        private System.Windows.Forms.Label labelwind;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblHumidityValue;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblRainChanceValue;
        private MetroFramework.Controls.MetroTabControl metroTabControl1; 
        private MetroFramework.Controls.MetroTabPage metroTabPageNhietDo;
        private MetroFramework.Controls.MetroTabPage metroTabPageLuongMua;
        private MetroFramework.Controls.MetroTabPage metroTabPageGio;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelDays;
        private System.Windows.Forms.PictureBox picMainWeatherIcon;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPrecipitation;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartWind;
    }
}