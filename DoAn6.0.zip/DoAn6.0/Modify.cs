﻿using System;
using System.Collections.Generic;
using System.Data; // Cần thêm using này
using System.Data.SqlClient; // Cần thêm using này
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; // Cần cho MessageBox trong các hàm xử lý lỗi chi tiết

namespace DoAn6._0 // Đảm bảo đúng namespace
{
    internal class Modify
    {
        // Constructor (có thể để trống)
        public Modify() { }

        // --- Phương thức thực thi lệnh INSERT, UPDATE, DELETE chung ---
        // (Được dùng bởi QuenMatKhau, có thể cả DangKy)
        public int ExecuteCommand(string query, List<SqlParameter> parameters)
        {
            int affectedRows = 0;
            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        if (parameters != null)
                        {
                            cmd.Parameters.AddRange(parameters.ToArray());
                        }
                        affectedRows = cmd.ExecuteNonQuery();
                    }
                }
                catch (SqlException ex)
                {
                    // Ghi log lỗi chi tiết hơn
                    Console.WriteLine($"Lỗi SQL khi thực thi: {query} - Lỗi: {ex.Message} (Số lỗi: {ex.Number})");
                    // Hiển thị thông báo lỗi thân thiện hơn cho người dùng nếu cần
                    // MessageBox.Show($"Lỗi cơ sở dữ liệu: {ex.Message}", "Lỗi SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    affectedRows = -1; // Gán giá trị để biết có lỗi SQL
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Lỗi thực thi lệnh: {query} - Lỗi: {ex.Message}");
                    // MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi hệ thống", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    affectedRows = -2; // Gán giá trị khác để biết có lỗi chung
                }
            }
            return affectedRows; // Trả về số dòng bị ảnh hưởng hoặc mã lỗi âm
        }

        // --- Phương thức kiểm tra đăng nhập ---
        // (Được dùng bởi DangNhap)
        public bool CheckLogin(string tenTaiKhoan, string matKhau)
        {
            bool isValid = false;
            // Lưu ý: Vẫn đang so sánh mật khẩu plain text
            string query = "SELECT COUNT(*) FROM TaiKhoan WHERE TK_TenTaiKhoan = @TenTaiKhoan COLLATE SQL_Latin1_General_CP1_CS_AS AND TK_MatKhau = @MatKhau COLLATE SQL_Latin1_General_CP1_CS_AS";
            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@TenTaiKhoan", tenTaiKhoan);
                        cmd.Parameters.AddWithValue("@MatKhau", matKhau); // So sánh plain text
                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            isValid = (Convert.ToInt32(result) > 0);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Lỗi khi kiểm tra đăng nhập cho {tenTaiKhoan}: {ex.Message}");
                    isValid = false; // Đặt lại thành false nếu có lỗi
                }
            }
            return isValid;
        }

        // --- Phương thức kiểm tra Tài khoản hoặc Email đã tồn tại chưa ---
        // (Được dùng bởi DangKy)
        public bool DoesAccountExist(string username, string email)
        {
            int count = 0;
            string query = "SELECT COUNT(*) FROM TaiKhoan WHERE TK_TenTaiKhoan = @TenTaiKhoan OR TK_Email = @Email";
            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        // Xử lý nếu username hoặc email là null/empty để tránh lỗi SQL
                        cmd.Parameters.AddWithValue("@TenTaiKhoan", string.IsNullOrEmpty(username) ? (object)DBNull.Value : username);
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email);

                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            count = Convert.ToInt32(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Lỗi kiểm tra tài khoản tồn tại (User: {username}, Email: {email}): {ex.Message}");
                    // Trong trường hợp lỗi CSDL khi kiểm tra, coi như tài khoản đã tồn tại để tránh tạo trùng
                    return true;
                }
            }
            return count > 0; // Trả về true nếu tìm thấy tài khoản/email trùng
        }

        // --- Phương thức kiểm tra Email tồn tại ---
        // (Được dùng bởi QuenMatKhau, có thể cả DangKy)
        public bool DoesEmailExist(string email)
        {
            int count = 0;
            string query = "SELECT COUNT(*) FROM TaiKhoan WHERE TK_Email = @Email";
            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email);
                        object result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            count = Convert.ToInt32(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Lỗi khi kiểm tra email tồn tại ({email}): {ex.Message}");
                    // Nếu có lỗi CSDL, không thể chắc chắn email có tồn tại hay không.
                    // Trả về false có thể dẫn đến thông báo "Email không tồn tại" sai.
                    // Có thể throw exception hoặc trả về một giá trị khác để báo lỗi.
                    // Tạm thời trả về false theo logic cũ.
                    return false;
                }
            }
            return count > 0; // Trả về true nếu email đã tồn tại
        }

        // --- Phương thức nội bộ để lấy ID Chủ ruộng tiếp theo ---
        // (Dùng cho việc đăng ký)
        private string GetNextCR_IDChuRuong(SqlConnection connection, SqlTransaction transaction)
        {
            string nextId = "CR01"; // ID bắt đầu
            // Câu lệnh này tìm số lớn nhất trong phần số của CR_IDChuRuong (ví dụ: 01, 02, ..., 99)
            // Đảm bảo chỉ xét các ID đúng định dạng 'CR' + 2 chữ số.
            string query = "SELECT MAX(TRY_CAST(SUBSTRING(CR_IDChuRuong, 3, 2) AS INT)) FROM dbo.QLChuRuong WITH (TABLOCKX, HOLDLOCK) WHERE CR_IDChuRuong LIKE 'CR[0-9][0-9]'";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, connection, transaction))
                {
                    object result = cmd.ExecuteScalar();
                    int maxNumber = 0; // Mặc định là 0 nếu chưa có ID nào hoặc lỗi

                    // Nếu kết quả không null và không phải DBNull thì chuyển đổi sang số nguyên
                    if (result != null && result != DBNull.Value)
                    {
                        maxNumber = (int)result;
                    }

                    int nextNumber = maxNumber + 1; // Số tiếp theo
                    nextId = $"CR{nextNumber:D2}"; // Định dạng thành "CR" + 2 chữ số (ví dụ: CR01, CR15)

                    // Kiểm tra tràn số (ví dụ: vượt quá CR99)
                    if (nextId.Length > 4) // Hoặc nextNumber > 99
                    {
                        throw new Exception("Không thể tạo ID Chủ ruộng mới, đã đạt giới hạn CR99.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi lấy Next CR_IDChuRuong: {ex.Message}");
                throw; // Ném lại lỗi để transaction có thể rollback
            }
            return nextId;
        }

        // --- Phương thức đăng ký tài khoản với Transaction ---
        // (Được dùng bởi DangKy)
        public string RegisterAccountWithTransaction(string tenTaiKhoan, string email, string matKhauPlainText)
        {
            string newCRID = null; // Biến lưu ID chủ ruộng mới được tạo
            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                sqlConnection.Open();
                SqlTransaction transaction = sqlConnection.BeginTransaction(); // Bắt đầu Transaction

                try
                {
                    // 1. Lấy ID Chủ ruộng tiếp theo (trong cùng transaction)
                    newCRID = GetNextCR_IDChuRuong(sqlConnection, transaction);

                    // 2. INSERT vào TaiKhoan trước, nhưng CR_IDChuRuong tạm thời là NULL
                    //    Điều này phá vỡ ràng buộc khóa ngoại tạm thời nếu có.
                    //    Hoặc cần đảm bảo FK cho phép NULL hoặc trì hoãn kiểm tra FK.
                    //    Cách an toàn hơn là chèn vào QLChuRuong trước nếu TK_TenTaiKhoan là khóa ngoại ở đó.
                    //    *Giả định theo code gốc là chèn vào TaiKhoan trước:*
                    string queryTaiKhoan = "INSERT INTO TaiKhoan (TK_TenTaiKhoan, TK_MatKhau, TK_Email, CR_IDChuRuong) VALUES (@TenTK, @MatKhau, @Email, NULL)"; // Để NULL CR_ID
                    using (SqlCommand cmdTaiKhoan = new SqlCommand(queryTaiKhoan, sqlConnection, transaction))
                    {
                        cmdTaiKhoan.Parameters.Add(new SqlParameter("@TenTK", SqlDbType.NVarChar) { Value = tenTaiKhoan });
                        cmdTaiKhoan.Parameters.Add(new SqlParameter("@MatKhau", SqlDbType.NVarChar) { Value = matKhauPlainText }); // Lưu plain text
                        cmdTaiKhoan.Parameters.Add(new SqlParameter("@Email", SqlDbType.NVarChar) { Value = email });
                        // Không cần tham số @IDChuRuong vì đã gán NULL trong query

                        int affectedTaiKhoan = cmdTaiKhoan.ExecuteNonQuery();
                        if (affectedTaiKhoan <= 0)
                        {
                            throw new Exception("Bước 1 thất bại: Không thể thêm vào bảng TaiKhoan.");
                        }
                        Console.WriteLine($"Bước 1: Inserted TaiKhoan {tenTaiKhoan} with NULL CR_IDChuRuong.");
                    }

                    // 3. INSERT vào QLChuRuong SAU, sử dụng newCRID và tham chiếu đến TaiKhoan vừa tạo
                    //    Cần đảm bảo cột CR_TenTaiKhoan trong QLChuRuong là khóa ngoại tham chiếu đến TaiKhoan.TK_TenTaiKhoan
                    //    và cột CR_CMND cho phép NULL (hoặc có giá trị default).
                    string queryChuRuong = "INSERT INTO QLChuRuong (CR_IDChuRuong, CR_HoTen, CR_TenTaiKhoan /*, các cột khác cho phép NULL */) VALUES (@IDChuRuong, @HoTen, @TenTaiKhoan)";
                    using (SqlCommand cmdChuRuong = new SqlCommand(queryChuRuong, sqlConnection, transaction))
                    {
                        cmdChuRuong.Parameters.Add(new SqlParameter("@IDChuRuong", SqlDbType.Char, 4) { Value = newCRID });
                        cmdChuRuong.Parameters.Add(new SqlParameter("@HoTen", SqlDbType.NVarChar) { Value = tenTaiKhoan }); // Dùng tạm tên TK làm Họ tên ban đầu
                        cmdChuRuong.Parameters.Add(new SqlParameter("@TenTaiKhoan", SqlDbType.NVarChar) { Value = tenTaiKhoan }); // Khóa ngoại liên kết lại TaiKhoan

                        int affectedChuRuong = cmdChuRuong.ExecuteNonQuery();
                        if (affectedChuRuong <= 0)
                        {
                            throw new Exception("Bước 2 thất bại: Không thể thêm vào bảng QLChuRuong.");
                        }
                        Console.WriteLine($"Bước 2: Inserted QLChuRuong {newCRID} linked to {tenTaiKhoan}.");
                    }

                    // 4. UPDATE TaiKhoan để gán đúng CR_IDChuRuong vừa tạo cho QLChuRuong
                    string queryUpdateTaiKhoan = "UPDATE TaiKhoan SET CR_IDChuRuong = @IDChuRuong WHERE TK_TenTaiKhoan = @TenTK";
                    using (SqlCommand cmdUpdateTaiKhoan = new SqlCommand(queryUpdateTaiKhoan, sqlConnection, transaction))
                    {
                        cmdUpdateTaiKhoan.Parameters.Add(new SqlParameter("@IDChuRuong", SqlDbType.Char, 4) { Value = newCRID });
                        cmdUpdateTaiKhoan.Parameters.Add(new SqlParameter("@TenTK", SqlDbType.NVarChar) { Value = tenTaiKhoan });

                        int affectedUpdate = cmdUpdateTaiKhoan.ExecuteNonQuery();
                        if (affectedUpdate <= 0)
                        {
                            // Ít khả năng xảy ra nếu bước 1 và 3 thành công, nhưng vẫn nên kiểm tra
                            throw new Exception("Bước 3 thất bại: Không thể cập nhật CR_IDChuRuong trong TaiKhoan.");
                        }
                        Console.WriteLine($"Bước 3: Updated TaiKhoan {tenTaiKhoan} with CR_IDChuRuong {newCRID}.");
                    }

                    // 5. Nếu tất cả thành công, Commit Transaction
                    transaction.Commit();
                    Console.WriteLine($"Đăng ký thành công cho {tenTaiKhoan} với CR_ID {newCRID}. Transaction committed.");
                    return newCRID; // Trả về ID chủ ruộng mới nếu thành công
                }
                catch (Exception ex) // Bắt bất kỳ lỗi nào trong quá trình thực thi
                {
                    // Ghi log lỗi chi tiết
                    string detailedError = $"Lỗi chi tiết trong Transaction Đăng ký:\n{ex.ToString()}";
                    Console.WriteLine(detailedError);
                    // Hiển thị thông báo lỗi cho người dùng (có thể ẩn chi tiết kỹ thuật)
                    MessageBox.Show($"Đăng ký thất bại. Đã xảy ra lỗi: {ex.Message}", "Lỗi Transaction Đăng Ký", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    try
                    {
                        transaction.Rollback(); // Cố gắng Rollback lại các thay đổi
                        Console.WriteLine("Transaction rolled back.");
                    }
                    catch (Exception rollbackEx)
                    {
                        Console.WriteLine($"Lỗi nghiêm trọng khi Rollback: {rollbackEx.Message}");
                        // Ghi log lỗi rollback
                    }
                    return null; // Trả về null nếu đăng ký thất bại
                }
            } // Kết nối sẽ tự động đóng khi ra khỏi using block
        }

        // --- Phương thức lấy thông tin Chủ Ruộng để cập nhật ---
        // (Được dùng bởi CapNhatTaiKhoan)
        public DataRow GetChuRuongInfo(string tenTaiKhoan)
        {
            DataRow dr = null;
            // Lấy các thông tin cần thiết từ QLChuRuong dựa vào CR_TenTaiKhoan
            string query = "SELECT CR_HoTen, CR_NgaySinh, CR_GioiTinh, CR_CMND, CR_DiaChi FROM QLChuRuong WHERE CR_TenTaiKhoan = @TenTaiKhoan";
            DataTable dataTable = new DataTable();

            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@TenTaiKhoan", tenTaiKhoan);
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dataTable); // Đổ dữ liệu vào DataTable
                        }
                    }

                    // Nếu có dữ liệu (ít nhất 1 dòng) thì lấy dòng đầu tiên
                    if (dataTable.Rows.Count > 0)
                    {
                        dr = dataTable.Rows[0];
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Lỗi khi lấy thông tin Chủ Ruộng cho tài khoản {tenTaiKhoan}: {ex.Message}");
                    MessageBox.Show($"Không thể tải thông tin tài khoản: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return dr; // Trả về DataRow (có thể là null)
        }

        // --- Phương thức cập nhật thông tin Chủ Ruộng ---
        // (Được dùng bởi CapNhatTaiKhoan)
        public bool UpdateChuRuongInfo(string tenTaiKhoan, string hoTen, DateTime? ngaySinh, string gioiTinh, string cmnd, string diaChi)
        {
            int affectedRows = 0;
            string query = @"UPDATE QLChuRuong
                           SET CR_HoTen = @HoTen,
                               CR_NgaySinh = @NgaySinh,
                               CR_GioiTinh = @GioiTinh,
                               CR_CMND = @CMND,
                               CR_DiaChi = @DiaChi
                           WHERE CR_TenTaiKhoan = @TenTaiKhoan"; // Cập nhật dựa trên Tên tài khoản

            using (SqlConnection sqlConnection = Connection.GetSqlConnection())
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                    {
                        // Thêm các tham số, xử lý cẩn thận giá trị NULL
                        cmd.Parameters.AddWithValue("@HoTen", string.IsNullOrEmpty(hoTen) ? (object)DBNull.Value : hoTen);
                        cmd.Parameters.AddWithValue("@NgaySinh", ngaySinh.HasValue ? (object)ngaySinh.Value : (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@GioiTinh", string.IsNullOrEmpty(gioiTinh) ? (object)DBNull.Value : gioiTinh);
                        cmd.Parameters.AddWithValue("@CMND", string.IsNullOrEmpty(cmnd) ? (object)DBNull.Value : cmnd);
                        cmd.Parameters.AddWithValue("@DiaChi", string.IsNullOrEmpty(diaChi) ? (object)DBNull.Value : diaChi);
                        cmd.Parameters.AddWithValue("@TenTaiKhoan", tenTaiKhoan); // Tham số cho điều kiện WHERE

                        affectedRows = cmd.ExecuteNonQuery();
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"Lỗi SQL khi cập nhật Chủ Ruộng ({tenTaiKhoan}): {ex.Message} (Số lỗi: {ex.Number})");
                    MessageBox.Show($"Lỗi SQL khi cập nhật: {ex.Message}", "Lỗi CSDL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false; // Cập nhật thất bại
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Lỗi không xác định khi cập nhật Chủ Ruộng ({tenTaiKhoan}): {ex.Message}");
                    MessageBox.Show($"Lỗi không xác định: {ex.Message}", "Lỗi Hệ Thống", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false; // Cập nhật thất bại
                }
            }
            // Trả về true nếu có ít nhất 1 dòng được cập nhật thành công
            return affectedRows > 0;
        }
    }
}